 
/**
 * Write a description of class RPS here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RPS
{
    public static void main (String Args [])
    {
        new RPS ();
    }
    
    public RPS ()
    {
        System.out.println ("Welcome! Let's play Rock, Paper, Scissors!");
        char response = IBIO.inputChar("\nWould you like to play? y/n ");
     
        int W = 0;
        int T = 0;
        int L = 0;
     
        while (response == 'y')
        {
           System.out.println ("\nOkay! Let's play!");
           System.out.println ("\nTo play this game, you have three options! Rock (R), Paper (P), and Scissors (S)! Scissors beats Paper, Paper beats Rock, Rock beats Scissors!");
            
           int playerchoice = (int) (Math.random() * 3) + 1;
           int computerchoice = (int) (Math.random() * 3) + 1;
           
           if (playerchoice == 1)
           {
                System.out.println ("\nYou got Rock!");
           }
           if (playerchoice == 2)
           {
                System.out.println ("\nYou got Paper!");
           }
           if (playerchoice == 3)
           {
                System.out.println ("\nYou got Scissors!");
           }
           
           if (computerchoice == 1)
           {
                System.out.println ("\nThe computer has selected Rock!");
           }
           if (computerchoice == 2)
           {
                System.out.println ("\nThe computer has selected Paper!");
           }
           if (computerchoice == 3)
           {
                System.out.println ("\nThe computer has selected Scissors!");
           }
               
           if ((computerchoice == 1 && playerchoice == 1) || (computerchoice == 2 && playerchoice == 2) || (computerchoice == 3 && playerchoice == 3))
           {
                System.out.println ("\nIt's a tie!");
                T++;
           }
           if ((computerchoice == 3 && playerchoice == 1) || (computerchoice == 1 && playerchoice == 2) || (computerchoice == 2 && playerchoice == 3))
           {
                System.out.println ("\nYou win!");
                W++;
           }
           if ((computerchoice == 2 && playerchoice == 1) || (computerchoice == 3 && playerchoice == 2) || (computerchoice == 1 && playerchoice == 3))
           { 
                System.out.println ("\nI win!");
                L++;
           }
           System.out.println ("\nWins: "+W);
           System.out.println ("Ties: "+T);
           System.out.println ("Losses: "+L);
           
           response = IBIO.inputChar("\nDo you want to play again? y/n "); 
        }
           
        if (response == 'n')
        {
             System.out.println ("\nGoodbye!");
             System.out.println ("Wins: "+W);
             System.out.println ("Ties: "+T);
             System.out.println ("Losses: "+L);
        }                
     }
}
                
